plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.shahid.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.shahid.tv"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        val siteUrl = (project.findProperty("siteUrl") as String?) ?: "https://CHANGE-ME.example.com"
        buildConfigField("String", "SITE_URL", "\"$siteUrl\"")
    }

    buildFeatures { buildConfig = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildTypes {
        release { isMinifyEnabled = false }
    }
}
