package com.shahid.tv

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    private fun siteUrl(): String = prefs.getString("url", BuildConfig.SITE_URL) ?: BuildConfig.SITE_URL

    // Focus + D-pad helper injected into the page (TV remote support)
    private val tvScript = """
        (function(){
          if(window.__tvInit)return; window.__tvInit=true;
          var s=document.createElement('style');
          s.textContent=':focus{outline:3px solid #e50914!important;outline-offset:2px;border-radius:6px}';
          document.head.appendChild(s);
          function mark(){
            document.querySelectorAll('[role=button],[onclick],a,button,[class*=cursor-pointer],[class*=card]').forEach(function(e){
              if(e.tabIndex<0&&!e.hasAttribute('tabindex'))e.tabIndex=0;
            });
          }
          mark();
          new MutationObserver(mark).observe(document.body,{childList:true,subtree:true});
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFocusable = true
            isFocusableInTouchMode = true
        }
        root.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
            userAgentString = userAgentString + " ShahidApp/1.0"
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: return false
                if (scheme == "http" || scheme == "https") return false
                // Schemes like vlc://, intent:// (external players)
                try {
                    val intent = if (scheme == "intent") Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                    else Intent(Intent.ACTION_VIEW, uri)
                    startActivity(intent)
                } catch (_: ActivityNotFoundException) {
                } catch (_: Exception) {
                }
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(tvScript, null)
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) showError(view)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCallback = callback
                web.visibility = View.GONE
                root.addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }

            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null
                customCallback?.onCustomViewHidden()
                customCallback = null
                web.visibility = View.VISIBLE
                web.requestFocus()
            }
        }

        if (siteUrl().contains("CHANGE-ME")) askUrl() else web.loadUrl(siteUrl())
    }

    private fun showError(view: WebView) {
        val url = siteUrl().replace("'", "")
        val html = """
            <html><body style="background:#181d25;color:#fff;font-family:sans-serif;text-align:center;padding-top:20vh">
            <h2>تعذّر الاتصال بالخادم</h2>
            <p>تحقق من الإنترنت أو من رابط الموقع (زر MENU لتغييره)</p>
            <button autofocus style="font-size:1.4em;padding:.6em 1.6em;background:#e50914;color:#fff;border:0;border-radius:8px"
              onclick="location.href='${'$'}url'">إعادة المحاولة</button>
            </body></html>
        """.trimIndent()
        view.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
    }

    private fun askUrl() {
        val input = EditText(this).apply {
            setText(siteUrl().takeIf { !it.contains("CHANGE-ME") } ?: "https://")
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("رابط الموقع")
            .setView(input)
            .setPositiveButton("حفظ") { _, _ ->
                var u = input.text.toString().trim()
                if (u.isNotEmpty()) {
                    if (!u.startsWith("http")) u = "https://$u"
                    prefs.edit().putString("url", u).apply()
                    web.loadUrl(u)
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MENU -> { askUrl(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                web.evaluateJavascript(
                    "(function(v){if(v){v.paused?v.play():v.pause()}})(document.querySelector('video'))", null
                )
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            web.canGoBack() -> web.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { root.removeAllViews(); web.destroy(); super.onDestroy() }
}
